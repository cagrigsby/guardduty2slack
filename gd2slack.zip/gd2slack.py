#This function uses an encrypted webhook URL. For it to work, you must scroll down to environment variables,
#open encryption config, enable helpers, and encrypt the key.
#Alternatively, remove encryption from the function.
#Slack channel is determined when you create the Slack webhook
import boto3
import json
import logging
import os

from base64 import b64decode
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError


# The base-64 encoded, encrypted key (CiphertextBlob) stored in the kmsEncryptedHookUrl environment variable
ENCRYPTED_HOOK_URL = os.environ['kmsEncryptedHookUrl']


HOOK_URL = "https://" + boto3.client('kms').decrypt(
    CiphertextBlob=b64decode(ENCRYPTED_HOOK_URL),
    EncryptionContext={'LambdaFunctionName': os.environ['AWS_LAMBDA_FUNCTION_NAME']}
)['Plaintext'].decode('utf-8')

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def lambda_handler(event, context):
    print(type(event))
    time = event["time"]
#    event_name = event["detail"]["eventName"]
#    event_source = event["detail"]["eventSource"]
    detail = event["detail"]["type"]
    severity = event["detail"]["severity"]
    description = event["detail"]["description"]
    account = event["account"]
    region = event["region"]
    
    slack_message = {
    	"blocks": [
    		{
    			"type": "section",
    			"text": {
    				"type": "mrkdwn",
    				"text": f"""GuardDuty event from CloudWatch
    				\n *Time:* {time}          *Region:* {region}         *Severity:* {severity}
    				\n *Detail Type:* {detail}
    				\n *Description:* {description}
    				\n *Account:* {account}
    				"""
    			}
    		}
    	]
    }
    
    print(slack_message)

    req = Request(HOOK_URL, json.dumps(slack_message).encode('utf-8'))
    try:
        response = urlopen(req)
        response.read()
        logger.info("Message posted to Slack")
    except HTTPError as e:
        logger.error("Request failed: %d %s", e.code, e.reason)
    except URLError as e:
        logger.error("Server connection failed: %s", e.reason)
